/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str_utils.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/11 17:01:19 by nsan              #+#    #+#             */
/*   Updated: 2024/12/13 19:26:59 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void detect_str(char *str, t_tokens tokens)
{
	int i;
	int word = 0;

	i = 0;
	while(str[i] != '\0')
	{
		if((str[i] >= 'a' && str[i] <= 'z') && str[i+1] == '\0' || (str[i] == '\"'))
		{
			tokens.tok_types = T_WORD;
			word++;
		}
		else if(str[i] == '>')
			tokens.tok_types = T_REDIRECT_OUT;
		i++;
	}
	if(!ft_strncmp(str, "|", 1))
		tokens.tok_types = T_PIPE;
	else if(!ft_strncmp(str, ">", 1))
		tokens.tok_types = T_REDIRECT_OUT;
	else if(!ft_strncmp(str, "<", 1))
		tokens.tok_types = T_REDIRECT_IN;
	else if(!ft_strncmp(str, ">>", 2))
		tokens.tok_types = T_APPEND;
	else if(!ft_strncmp(str, "<<", 2))
		tokens.tok_types = T_HERE_DOCS;
	else if(!ft_strncmp(str, "&&", 2))
		tokens.tok_types = T_AND;
	else if(!ft_strncmp(str, "||", 2))
		tokens.tok_types = T_OR;
	else if(!ft_strncmp(str, "(", 1))
		tokens.tok_types = T_LPAREN;
	else if(!ft_strncmp(str, ")", 1))
		tokens.tok_types = T_RPAREN;
	else if(!ft_strncmp(str, "$", 1))
		tokens.tok_types = T_VAR;
	else if(!ft_strncmp(str, "EOF", 3))	
		tokens.tok_types = T_EOF;
	printf("[ %s ] token : %d\n", str, tokens.tok_types);
	// printf("word count : %d\n", word);
	// if(word >= 1)
	// 	return (1);
	// return (0);
}
