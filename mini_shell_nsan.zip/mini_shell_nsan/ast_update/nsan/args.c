#include "minishell.h"

void args_list_len_alloc(t_tokens **whole_list, char ***args_list) //lenght alloc need to be separated for each args_list & redirection list
{
    int args_len = 0;
    t_tokens *current;

    current = *whole_list;
    //if the input cmd is word and not until pipe
    while(current->tok_types != T_PIPE)
    {
        if(current->tok_types == T_WORD)
            args_len++;
        else if(current->tok_types == T_REDIRECT_OUT)
        {
            if(current->next->tok_types == T_WORD)
                current = current->next;
        }
        current = current->next;
    }
    if(args_len == 0)
        *args_list = NULL;
    if(args_len > 0)
        *args_list = malloc(sizeof(char *) * (args_len + 1));
}


t_ast *args_list(t_ast *node, t_tokens **whole_list) //will have to return the ast_node(right node of the cmd_list)
{
    char **args_list;
    args_list_len_alloc(whole_list, &args_list);
    // printf("VAINPOT HERE\n");
    node->cmd = parse_cmd(&args_list, whole_list, 1);
    return (node);
}

