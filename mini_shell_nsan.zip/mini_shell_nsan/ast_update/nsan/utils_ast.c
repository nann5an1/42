#include "minishell.h"

void ast(t_tokens **whole_list)
{
	int i;
	t_ast *ast_node;
	t_tokens *current;
	int flag = 0;

	i = 0;
	
	current = *whole_list;
	ast_node = malloc(sizeof(t_ast));
	if(!ast_node)
		printf("Error in main_ast malloc\n");
	
	if(ft_strncmp(current->str, "|", 1))
	{
		// printf("vainpot 1\n");
		cmd_node_branch(current);	
	}
	// else if(ft_strncmp(current->str, "|", 1) == 0)
	// {
	// 	ast_node->right = ast(whole_list)
	// }
	// current = current->next;
	// return (ast_node);
}
	

// t_ast *ast(t_tokens **whole_list)
// {
//     t_tokens *current = *whole_list;
//     t_ast *root = NULL;

//     while (current)
//     {
//         if (ft_strncmp(current->str, "|", 1) == 0)
//         {
//             // Create a PIPE node and parse its children
//             t_ast *pipe_node = malloc(sizeof(t_ast));
//             if (!pipe_node)
//                 return NULL; // Handle malloc failure
//             // pipe_node->type = ft_strdup("PIPE");
//             pipe_node->left = root; // Attach the left subtree
//             pipe_node->right = NULL;
//             current = current->next; // Move to the next token

//             pipe_node->right = parse_pipe(&current); // Parse the right subtree
//             root = pipe_node; // Update the root to the PIPE node
//         }
//         else
//         {
//             // If no pipe, parse a single command
//             root = parse_pipe(&current);
//         }
//     }
// 	if (root)
// 	{
// 		// printf("AST Root Node Type: %s\n", root->type);
// 		if (root->cmd)
// 		{
// 			for (int j = 0; root->cmd[j]; j++)
// 			{
// 				printf("  Root Command[%d]: %s\n", j, root->cmd[j]);
// 			}
// 		}
// 	}

//     return root;
// }