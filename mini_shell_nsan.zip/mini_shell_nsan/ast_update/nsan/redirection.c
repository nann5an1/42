#include "minishell.h"



void redirect_list_len_alloc(t_tokens **whole_list, char ***redirect_list)
{
    int redirect_len;
    t_tokens *current;

    redirect_len = 0;
    current = *whole_list;
    // printf("vainpot 5\n");
    while(current->tok_types != T_PIPE)
    {
        if(current->tok_types == T_REDIRECT_OUT)
        {
            if(current->next->tok_types == T_WORD)
            {
                redirect_len += 2;
                current = current->next;
            }
        }
        current = current->next;
    }
    // printf("REDIRECTION LENGTH : %d \n", redirect_len);
    if(redirect_len > 0)
        *redirect_list = malloc(sizeof(char *) * (redirect_len + 1));
}



t_ast *redirection_list(t_ast *node, t_tokens **whole_list)
{
    char **redirect_list;

    // *redirect_list = NULL;
    // printf("vainpot 4\n");
    redirect_list_len_alloc(whole_list, &redirect_list);
    node->cmd = parse_cmd(&redirect_list, whole_list, 0);
    return (node);
}