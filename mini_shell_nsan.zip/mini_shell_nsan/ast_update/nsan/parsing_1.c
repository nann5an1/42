#include "minishell.h"

void parse_pipe(t_tokens **whole_list, t_ast *ast_node)
{
    t_tokens *ref_ptr = *whole_list;
    t_tokens *temp_ptr = *whole_list; //for traversing and getting the count for malloc
    t_ast *arg_ast_node = ast_node->left->right;
    int i = 0;
    int j = 0;
    int k = 0;
    char **list_of_cmd;
    
    //traverse for the malloc
    while(temp_ptr && ft_strncmp(temp_ptr->str, "|", 1))
    {
        if(temp_ptr->tok_types == 0)
            i++;
        else if(temp_ptr->tok_types == 2 || temp_ptr->tok_types == 3) //now only tested for < and >
        {
            j++;
            temp_ptr = temp_ptr->next;
        }
        temp_ptr = temp_ptr->next;
    }
    if(i > 0)
    {
        arg_ast_node->cmd = malloc(sizeof(char *) * (i + 1));
        if(!arg_ast_node->cmd)
            printf("Memory allocation fails\n");
        // (arg_ast_node->cmd)[i] = NULL;
        list_of_cmd = arg_ast_node->cmd;
    }
    // printf("size for redirection : %d\n", j);
    while (ref_ptr && ft_strncmp(ref_ptr->str, "|", 1))
    {
        //ast_node->left will be the branch of the main ast_pipe_node
        // if(ref_ptr && ref_ptr->tok_types == T_REDIRECT_IN && ref_ptr->next->tok_types == T_WORD)
        //     parse_cmd_redirections(ast_node->left, cmd_list, ref_ptr); //add the str keyword to the left-node of cmd, which is left-node of main ast-node
        //sth needs to be refined for the contents output

        printf("ref prt STR: %s\n", ref_ptr->str);
        if((ref_ptr && ref_ptr->tok_types == 0))
        {
            // printf("value of k: %d\n", k);
            *list_of_cmd = ft_strdup(ref_ptr->str);
            *(list_of_cmd)++;
            printf("CONTENT: %s \n",arg_ast_node->cmd[k]);
            k++;
        }
        ref_ptr = ref_ptr->next;
    }
    whole_list = ref_ptr;
}


// t_ast *parse_pipe(t_tokens **whole_list)
// {
//     t_tokens *current = *whole_list;
//     t_ast *cmd_node = malloc(sizeof(t_ast));
//     if (!cmd_node)
//         return NULL; // Handle malloc failure
//     // cmd_node->type = ft_strdup("CMD");
//     cmd_node->cmd = NULL;
//     cmd_node->left = NULL;
//     cmd_node->right = NULL;

//     int cmd_count = 0;

//     // Count command arguments
//     t_tokens *temp = current;
//     while (temp && ft_strncmp(temp->str, "|", 1) != 0)
//     {
//         if (temp->tok_types == 0) // Check for a command or argument
//             cmd_count++;
//         temp = temp->next;
//     }

//     // Allocate memory for command arguments
//     if (cmd_count > 0)
//     {
//         cmd_node->cmd = malloc(sizeof(char *) * (cmd_count + 1));
//         if (!cmd_node->cmd)
//             return NULL; // Handle malloc failure
//         cmd_node->cmd[cmd_count] = NULL; // Null-terminate the array
//     }

//     // Populate command arguments
//     int i = 0;
//     while (current && ft_strncmp(current->str, "|", 1) != 0)
//     {
//         if (current->tok_types == 0) // Check for a command or argument
//         {
//             cmd_node->cmd[i] = ft_strdup(current->str);
//             printf("Added command/argument to AST: %s\n", cmd_node->cmd[i]);
//             i++;
//         }
//         else if (current->tok_types == 2 || current->tok_types == 3) // Handle redirections
//         {
//             // Create a REDIR node
//             t_ast *redir_node = malloc(sizeof(t_ast));
//             if (!redir_node)
//                 return NULL; // Handle malloc failure
//             // redir_node->type = (current->tok_types == 2) ? ft_strdup("REDIR_IN") : ft_strdup("REDIR_OUT");
//             redir_node->cmd = NULL;
//             redir_node->left = cmd_node;
//             redir_node->right = NULL;

//             current = current->next; // Move to the file name
//             if (current)
//                 redir_node->cmd = malloc(sizeof(char *) * 2);
//             redir_node->cmd[0] = ft_strdup(current->str);
//             redir_node->cmd[1] = NULL;

//             cmd_node = redir_node; // Update the current node
//         }
//         current = current->next;
//     }

//     *whole_list = current; // Update the token list pointer
//     return cmd_node;
// }

// char **cmd_list(char **list_of_cmd, t_tokens *ref_ptr, int size)
// {
//     // printf("inside cmd_list\n");
//     int i = 0;
//     while(i < size)
//     {
//         list_of_cmd[i] = ft_strdup(ref_ptr->str);
//         i++;
//     }
//     list_of_cmd[i] = NULL;
//     return (list_of_cmd);
// }

// void parse_pipe(t_tokens **whole_list, t_ast *ast_node)
// {
//     t_tokens *ref_ptr = *whole_list;
//     t_tokens *temp_ptr = *whole_list; //for traversing and getting the count for malloc
//     t_ast *arg_ast_node = ast_node->left->right;
//     int i = 0;
//     int j = 0;
//     int k = 0;
//     char **list_of_cmd;
    
//     //traverse for the malloc
//     while(temp_ptr && ft_strncmp(temp_ptr->str, "|", 1))
//     {
//         if(temp_ptr->tok_types == 0)
//             i++;
//         else if(temp_ptr->tok_types == 2 || temp_ptr->tok_types == 3) //now only tested for < and >
//         {
//             j++;
//             temp_ptr = temp_ptr->next;
//         }
//         temp_ptr = temp_ptr->next;
//     }
//     if(i > 0)
//     {
//         arg_ast_node->cmd = malloc(sizeof(char *) * (i + 1));
//         if(!arg_ast_node->cmd)
//             printf("Memory allocation fails\n");
//         // (arg_ast_node->cmd)[i] = NULL;
//         list_of_cmd = arg_ast_node->cmd;
//     }
//     // printf("size for redirection : %d\n", j);
//     while (ref_ptr && ft_strncmp(ref_ptr->str, "|", 1))
//     {
//         //ast_node->left will be the branch of the main ast_pipe_node
//         // if(ref_ptr && ref_ptr->tok_types == T_REDIRECT_IN && ref_ptr->next->tok_types == T_WORD)
//         //     parse_cmd_redirections(ast_node->left, cmd_list, ref_ptr); //add the str keyword to the left-node of cmd, which is left-node of main ast-node
//         //sth needs to be refined for the contents output

//         printf("ref prt STR: %s\n", ref_ptr->str);
//         if((ref_ptr && ref_ptr->tok_types == 0))
//         {
//             // printf("value of k: %d\n", k);
//             *list_of_cmd = ft_strdup(ref_ptr->str);
//             *(list_of_cmd)++;
//             printf("CONTENT: %s \n",arg_ast_node->cmd[k]);
//             k++;
//         }
//         ref_ptr = ref_ptr->next;
//     }
   
// }

//second level node branched out from main-pipe-ast-node
// void parse_cmd_redirections(t_ast *cmd_ast_node, t_tokens *ref_ptr) 
// {
//     cmd_ast_node->left = parse_cmd();
// }

//second level node branched out from main-pipe-ast-node
// void parse_cmd_arguments(t_ast *cmd_ast_node, t_tokens *ref_ptr)
// {
//     cmd_ast_node->right = cmd_list(cmd_list, ref_ptr);
// }



