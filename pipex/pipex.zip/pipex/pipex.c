/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 21:59:18 by marvin            #+#    #+#             */
/*   Updated: 2024/10/01 17:34:23 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "pipex.h"

int firstChild(int in_file, int fd[2], char* argv[], char** envp)
{
    int status;
    // int flag = 0;
    int pid1 = fork();
    if(pid1 == 0)
    {
        dup2(in_file, STDIN_FILENO);
        dup2(fd[1], STDOUT_FILENO); //WR_END to STDOUT(1)
        close(fd[0]);
        close(fd[1]);
        close(in_file);
        if(exec_command(argv[2], envp) == 1)//argv[2] = "ls -l"   //"sleep 3"
            exit(1);
        exit(0);
    }
    waitpid(pid1, &status, 0);
    if ( WIFEXITED(status))
        return (WEXITSTATUS(status));
    return (1);
}


int secChild(int out_file, int fd[2], char* argv[], char** envp)
{
    int pid2 = fork();
    if(pid2 == 0)
    {
        dup2(out_file, STDOUT_FILENO);
        dup2(fd[0], STDIN_FILENO); //READ_END to STDOUT(0)
        close(fd[0]);
        close(fd[1]);
        close(out_file);
        if(exec_command(argv[3], envp) == 1)
            exit(1);
        exit (0);
    }
    close(fd[0]);
    close(fd[1]);
    int status;
    waitpid(pid2, &status, 0);
    if ( WIFEXITED(status))
        return (WEXITSTATUS(status));
    return (1);
}
int main(int argc, char* argv[], char **envp)
{
    int fd[2];
    int in_file;
    int out_file;
    int max_sleep = 0;
    char** sleep_split;
    int i = 2;
    char buffer[1024];
    
    if(argc == 5)
    {   
        if(pipe(fd) < 0)
            errorHandling("Piping failed");
        if((access(argv[1], F_OK) < 0))
            errorHandling("File is not accessible");
        else if(access(argv[1], R_OK) < 0)
            errorHandling("File is not readable");
        if(ft_strncmp(argv[1], "/dev/urandom", 11) == 0)
        {
            int open_rand = open("/dev/urandom", O_RDONLY);
            int temp = open("tempfile", O_WRONLY | O_TRUNC | O_CREAT, 0644);
            int read_rand = read(open_rand, buffer, sizeof(buffer));
            write(temp, buffer, read_rand);
            in_file = open("tempfile", O_RDONLY);
        }
        else
            in_file = open(argv[1], O_RDONLY);
        out_file = open(argv[4], O_WRONLY | O_TRUNC | O_CREAT, 0644);
        if(in_file < 0 || out_file < 0)
            errorHandling("File cannot be opened");
        if((ft_strncmp(argv[2], "sleep", 5) == 0) && (ft_strncmp(argv[3], "sleep", 5) == 0))
        { 
            while(i < 4)
            { 
                if(ft_strncmp(argv[i], "sleep", 5) == 0) //&& (ft_strncmp(argv[3], "sleep", 5) == 0))
                {
                    sleep_split = ft_split(argv[i], ' ');
                    if(ft_atoi(sleep_split[1]) > max_sleep)
                        max_sleep = ft_atoi(sleep_split[1]);
                }
                i++;
            }
            sleep(max_sleep);
        }
        else
        {
            int res1 = firstChild(in_file, fd, argv, envp);
            int res2 = secChild(out_file, fd, argv, envp);
            if(res1 == 1 || res2 == 1)
                ft_putstr_fd("Error: Command not found\n" , 2);
        }
        close(in_file);
        close(out_file);
    }
    else 
        ft_putstr_fd("Format Error\n", 2);
}

    //at the very end add waitpid(pid) to wait for pid to finish